# This folder contains the necessary test file and input arguments for Python_Face_Detect_Mouth_Detect
# 

Usage: 

1.place this folder inside the main folder . where contains FaceDetection.py 
2.run in terminal: pyhton FaceDetection.py [JSON_INPUT]
3.[JSON_INPUT] should be replaced with actural json, which can be found in 'test_input_json.txt'




